// ============================================================
//  TeleGuard — Shared UI Components
// ============================================================
import React from 'react';
import { FRAUD_TYPES, SEVERITY } from '../data/mockData';

// ── Fraud Type Badge ─────────────────────────────────────────
export function FraudBadge({ type, small }) {
  const t = FRAUD_TYPES[type] || {};
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      background: t.bg, color: t.color,
      border: `1px solid ${t.color}33`,
      borderRadius: 5,
      padding: small ? '3px 8px' : '5px 12px',
      fontSize: small ? 10 : 12,
      fontFamily: 'var(--mono)',
      fontWeight: 700, letterSpacing: '0.5px',
      whiteSpace: 'nowrap',
    }}>
      {t.icon} {t.label}
    </span>
  );
}

// ── Severity Badge ───────────────────────────────────────────
export function SeverityBadge({ level }) {
  const s = SEVERITY[level] || SEVERITY.LOW;
  return (
    <span style={{
      display: 'inline-block',
      background: s.color + '18',
      color: s.color,
      border: `1px solid ${s.color}44`,
      borderRadius: 5,
      padding: '3px 9px',
      fontSize: 11,
      fontFamily: 'var(--mono)',
      fontWeight: 700,
      letterSpacing: '1px',
      textTransform: 'uppercase',
    }}>
      {s.label}
    </span>
  );
}

// ── Status Pill ──────────────────────────────────────────────
const STATUS_COLORS = {
  OPEN:           { bg: 'rgba(255,68,102,0.12)',  color: '#ff4466' },
  INVESTIGATING:  { bg: 'rgba(245,158,11,0.12)',  color: '#f59e0b' },
  RESOLVED:       { bg: 'rgba(0,229,160,0.12)',   color: '#00e5a0' },
  DISMISSED:      { bg: 'rgba(91,111,138,0.12)',  color: '#5b6f8a' },
  FLAGGED:        { bg: 'rgba(255,68,102,0.12)',  color: '#ff4466' },
  CLEAN:          { bg: 'rgba(0,229,160,0.12)',   color: '#00e5a0' },
};
export function StatusPill({ status }) {
  const s = STATUS_COLORS[status] || STATUS_COLORS.DISMISSED;
  return (
    <span style={{
      background: s.bg, color: s.color,
      border: `1px solid ${s.color}44`,
      borderRadius: 20,
      padding: '4px 12px',
      fontSize: 11, fontFamily: 'var(--mono)',
      fontWeight: 700, letterSpacing: '0.8px',
      textTransform: 'uppercase',
    }}>
      {status}
    </span>
  );
}

// ── Confidence Bar ───────────────────────────────────────────
export function ConfidenceBar({ value }) {
  const color = value >= 90 ? '#ff4466' : value >= 75 ? '#f59e0b' : '#00e5a0';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{ flex: 1, height: 5, background: 'var(--bg-hover)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: `${value}%`, height: '100%', background: color, borderRadius: 3,
          boxShadow: `0 0 8px ${color}88`, transition: 'width 0.6s ease' }} />
      </div>
      <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color, fontWeight: 700, minWidth: 36 }}>
        {value}%
      </span>
    </div>
  );
}

// ── Card container ───────────────────────────────────────────
export function Card({ children, style = {}, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-dim)',
        borderRadius: 'var(--radius-lg)',
        padding: '20px 24px',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'border-color 0.2s, box-shadow 0.2s',
        ...style,
      }}
      onMouseEnter={e => { if(onClick) { e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.boxShadow='0 4px 24px rgba(0,229,160,0.06)'; }}}
      onMouseLeave={e => { if(onClick) { e.currentTarget.style.borderColor='var(--border-dim)'; e.currentTarget.style.boxShadow='none'; }}}
    >
      {children}
    </div>
  );
}

// ── Page Header ──────────────────────────────────────────────
export function PageHeader({ title, subtitle, children }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
      <div>
        <h1 style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.5px' }}>{title}</h1>
        {subtitle && <p style={{ color: 'var(--muted)', fontSize: 14, marginTop: 5 }}>{subtitle}</p>}
      </div>
      {children && <div style={{ display: 'flex', gap: 10 }}>{children}</div>}
    </div>
  );
}

// ── Button ───────────────────────────────────────────────────
export function Btn({ children, variant = 'primary', onClick, small, style = {} }) {
  const base = {
    border: 'none', borderRadius: 8, cursor: 'pointer',
    fontFamily: 'var(--font)', fontWeight: 700,
    padding: small ? '8px 16px' : '11px 22px',
    fontSize: small ? 12 : 14,
    transition: 'opacity 0.15s, transform 0.15s',
    display: 'inline-flex', alignItems: 'center', gap: 7,
    ...style,
  };
  const variants = {
    primary:  { background: 'var(--accent)', color: '#07090f', boxShadow: '0 0 18px var(--accent-glow)' },
    danger:   { background: 'rgba(255,68,102,0.15)', color: '#ff4466', border: '1px solid rgba(255,68,102,0.3)' },
    ghost:    { background: 'var(--bg-hover)', color: 'var(--text)', border: '1px solid var(--border-dim)' },
    outline:  { background: 'transparent', color: 'var(--accent)', border: '1px solid var(--border)' },
  };
  return (
    <button
      onClick={onClick}
      style={{ ...base, ...variants[variant] }}
      onMouseEnter={e => { e.currentTarget.style.opacity='0.85'; e.currentTarget.style.transform='translateY(-1px)'; }}
      onMouseLeave={e => { e.currentTarget.style.opacity='1'; e.currentTarget.style.transform='translateY(0)'; }}
    >
      {children}
    </button>
  );
}

// ── Live dot ─────────────────────────────────────────────────
export function LiveDot() {
  return (
    <span style={{ position: 'relative', display: 'inline-block', width: 8, height: 8 }}>
      <span style={{
        position: 'absolute', inset: 0, borderRadius: '50%',
        background: 'var(--accent)',
        animation: 'livePulse 2s infinite',
      }} />
      <style>{`@keyframes livePulse{0%{box-shadow:0 0 0 0 rgba(0,229,160,0.5)}70%{box-shadow:0 0 0 8px transparent}100%{box-shadow:0 0 0 0 transparent}}`}</style>
    </span>
  );
}

// ── Section Label ─────────────────────────────────────────────
export function SectionLabel({ children }) {
  return (
    <div style={{
      fontFamily: 'var(--mono)', fontSize: 10, fontWeight: 700,
      color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '2px',
      marginBottom: 12,
    }}>
      {children}
    </div>
  );
}
