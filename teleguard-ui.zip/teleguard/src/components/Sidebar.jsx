// ============================================================
//  TeleGuard — Sidebar Navigation
// ============================================================
import React from 'react';
import { LiveDot } from './UI';

const NAV_ITEMS = [
  { id: 'dashboard',    label: 'Dashboard',      icon: '▣' },
  { id: 'alerts',       label: 'Alerts Center',  icon: '🔔', badge: 47 },
  { id: 'case',         label: 'Investigate',    icon: '🔍' },
  { id: 'analytics',    label: 'Analytics',      icon: '📊' },
  { id: 'subscriber',   label: 'Subscribers',    icon: '👤' },
  { id: 'audit',        label: 'Audit Log',      icon: '📋' },
  { id: 'settings',     label: 'Settings',       icon: '⚙️' },
];

export function Sidebar({ active, onNavigate }) {
  return (
    <aside style={{
      width: 220,
      minWidth: 220,
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-dim)',
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      position: 'sticky',
      top: 0,
      flexShrink: 0,
    }}>

      {/* Brand */}
      <div style={{
        padding: '24px 20px 22px',
        borderBottom: '1px solid var(--border-dim)',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{
          width: 36, height: 36,
          background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
          borderRadius: 9, display: 'flex', alignItems: 'center',
          justifyContent: 'center', fontSize: 17, flexShrink: 0,
        }}>🛡</div>
        <div>
          <div style={{ fontWeight: 800, fontSize: 16, letterSpacing: '-0.3px' }}>
            Tele<span style={{ color: 'var(--accent)' }}>Guard</span>
          </div>
          <div style={{ fontSize: 10, color: 'var(--muted)', fontFamily: 'var(--mono)', letterSpacing: '1px', marginTop: 1 }}>
            AI FRAUD SYSTEM
          </div>
        </div>
      </div>

      {/* Live status */}
      <div style={{
        margin: '14px 16px', padding: '10px 14px',
        background: 'rgba(0,229,160,0.05)',
        border: '1px solid rgba(0,229,160,0.12)',
        borderRadius: 8,
        display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <LiveDot />
        <span style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--accent)', letterSpacing: '0.5px' }}>
          Monitoring Active
        </span>
      </div>

      {/* Nav section label */}
      <div style={{
        padding: '4px 20px 8px',
        fontSize: 10, fontFamily: 'var(--mono)',
        color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '2px',
      }}>
        Navigation
      </div>

      {/* Nav links */}
      <nav style={{ flex: 1, padding: '0 10px' }}>
        {NAV_ITEMS.map(item => {
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              style={{
                width: '100%', display: 'flex', alignItems: 'center',
                gap: 11, padding: '10px 12px', borderRadius: 8,
                border: 'none', cursor: 'pointer', textAlign: 'left',
                marginBottom: 2,
                background: isActive ? 'rgba(0,229,160,0.1)' : 'transparent',
                color: isActive ? 'var(--accent)' : 'var(--muted)',
                fontFamily: 'var(--font)', fontSize: 14, fontWeight: isActive ? 700 : 500,
                borderLeft: isActive ? '2px solid var(--accent)' : '2px solid transparent',
                transition: 'all 0.15s',
              }}
              onMouseEnter={e => { if (!isActive) { e.currentTarget.style.background='var(--bg-hover)'; e.currentTarget.style.color='var(--text)'; }}}
              onMouseLeave={e => { if (!isActive) { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--muted)'; }}}
            >
              <span style={{ fontSize: 15, width: 20, textAlign: 'center' }}>{item.icon}</span>
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.badge && (
                <span style={{
                  background: '#ff4466', color: '#fff',
                  borderRadius: 10, padding: '1px 7px',
                  fontSize: 10, fontFamily: 'var(--mono)', fontWeight: 700,
                }}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Admin user */}
      <div style={{
        padding: '16px 16px 20px',
        borderTop: '1px solid var(--border-dim)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 34, height: 34, borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, fontWeight: 800, color: '#07090f', flexShrink: 0,
        }}>A</div>
        <div style={{ overflow: 'hidden' }}>
          <div style={{ fontSize: 13, fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            Admin User
          </div>
          <div style={{ fontSize: 10, color: 'var(--muted)', fontFamily: 'var(--mono)' }}>
            admin@teleguard.net
          </div>
        </div>
      </div>
    </aside>
  );
}
