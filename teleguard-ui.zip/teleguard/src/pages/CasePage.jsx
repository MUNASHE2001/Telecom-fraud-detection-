// ============================================================
//  Stage 4 — Case Investigation (with SHAP evidence)
// ============================================================
import React, { useState } from 'react';
import { caseDetail } from '../data/mockData';
import { FraudBadge, SeverityBadge, StatusPill, Card, PageHeader, Btn, SectionLabel } from '../components/UI';

export default function CasePage({ onNavigate }) {
  const c = caseDetail;
  const [status, setStatus] = useState(c.status);

  return (
    <div style={{ padding:'32px 36px', maxWidth:1200 }}>
      <PageHeader
        title={`Case Investigation — ${c.id}`}
        subtitle="Deep-dive analysis with AI explanation (SHAP values)"
      >
        <Btn variant="ghost" small onClick={()=>onNavigate('alerts')}>← Back to Alerts</Btn>
        <Btn variant="danger" small onClick={()=>setStatus('RESOLVED')}>✓ Mark Resolved</Btn>
        <Btn variant="primary" small>⛔ Block Account</Btn>
      </PageHeader>

      {/* ── Top meta bar ── */}
      <Card style={{ marginBottom:24, padding:'18px 24px' }}>
        <div style={{ display:'flex', flexWrap:'wrap', gap:32, alignItems:'center' }}>
          <div><SectionLabel>Alert ID</SectionLabel><span style={{ fontFamily:'var(--mono)', fontSize:15, fontWeight:700 }}>{c.id}</span></div>
          <div><SectionLabel>Fraud Type</SectionLabel><FraudBadge type={c.type} /></div>
          <div><SectionLabel>Severity</SectionLabel><SeverityBadge level={c.severity} /></div>
          <div><SectionLabel>Status</SectionLabel><StatusPill status={status} /></div>
          <div>
            <SectionLabel>Confidence</SectionLabel>
            <span style={{ fontFamily:'var(--mono)', fontSize:22, fontWeight:800, color:'#ff4466' }}>{c.confidence}%</span>
          </div>
          <div><SectionLabel>Detected At</SectionLabel><span style={{ fontFamily:'var(--mono)', fontSize:13 }}>{c.detectedAt}</span></div>
        </div>
      </Card>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, marginBottom:20 }}>

        {/* ── Subscriber Profile ── */}
        <Card>
          <SectionLabel>Subscriber Profile</SectionLabel>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginTop:8 }}>
            {[
              ['Phone Number',   c.subscriber.number],
              ['Account ID',     c.subscriber.account],
              ['Name',           c.subscriber.name],
              ['Network',        c.subscriber.network],
              ['Registered',     c.subscriber.registeredAt],
              ['ID Verified',    c.subscriber.idVerified ? '✅ Yes' : '❌ No'],
            ].map(([label, value]) => (
              <div key={label}>
                <div style={{ fontSize:11, color:'var(--muted)', fontFamily:'var(--mono)', textTransform:'uppercase', letterSpacing:'1px', marginBottom:4 }}>{label}</div>
                <div style={{ fontSize:14, fontWeight:600, color: label==='ID Verified' && !c.subscriber.idVerified ? '#ff4466' : 'var(--text)' }}>{value}</div>
              </div>
            ))}
          </div>
          <div style={{ marginTop:20, padding:'12px 14px', background:'rgba(255,68,102,0.07)', border:'1px solid rgba(255,68,102,0.2)', borderRadius:8, fontSize:13, color:'#ff8888', lineHeight:1.6 }}>
            ⚠ Account registered 28 days ago. ID verification failed. Activity pattern consistent with Wangiri fraud campaign.
          </div>
        </Card>

        {/* ── Detection Timeline ── */}
        <Card>
          <SectionLabel>Detection Timeline</SectionLabel>
          <div style={{ marginTop:8 }}>
            {c.timeline.map((t, i) => (
              <div key={i} style={{ display:'flex', gap:14, paddingBottom: i<c.timeline.length-1 ? 16 : 0, position:'relative' }}>
                {i < c.timeline.length-1 && (
                  <div style={{ position:'absolute', left:7, top:18, bottom:0, width:1, background:'var(--border-dim)' }} />
                )}
                <div style={{ width:15, height:15, borderRadius:'50%', background:'var(--accent)', border:'2px solid var(--bg-card)', flexShrink:0, marginTop:1, zIndex:1 }} />
                <div>
                  <div style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--accent)', marginBottom:3 }}>{t.time}</div>
                  <div style={{ fontSize:13, color:'var(--text)' }}>{t.event}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* ── SHAP Evidence ── */}
      <Card style={{ marginBottom:20 }}>
        <SectionLabel>AI Explanation — SHAP Feature Importance</SectionLabel>
        <p style={{ fontSize:13, color:'var(--muted)', marginBottom:20, marginTop:4 }}>
          The features below explain why the model classified this as Wangiri fraud. Larger bars = stronger contribution to the fraud score.
        </p>
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {c.evidence.map((ev, i) => {
            const impactColor = ev.impact === 'high' ? '#ff4466' : ev.impact === 'medium' ? '#f59e0b' : '#00e5a0';
            return (
              <div key={i}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                    <span style={{ fontFamily:'var(--mono)', fontSize:13, color:'var(--text)' }}>{ev.feature}</span>
                    <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)', background:'var(--bg-hover)', borderRadius:4, padding:'2px 8px' }}>{ev.value}</span>
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                    <span style={{ fontSize:11, color:impactColor, fontFamily:'var(--mono)', fontWeight:700, textTransform:'uppercase' }}>{ev.impact}</span>
                    <span style={{ fontFamily:'var(--mono)', fontSize:12, color:impactColor, fontWeight:700, minWidth:36 }}>{ev.weight}%</span>
                  </div>
                </div>
                <div style={{ height:8, background:'var(--bg-hover)', borderRadius:4, overflow:'hidden' }}>
                  <div style={{
                    width:`${ev.weight * 3}%`, maxWidth:'100%', height:'100%',
                    background: `linear-gradient(90deg, ${impactColor}cc, ${impactColor}55)`,
                    borderRadius:4, boxShadow:`0 0 10px ${impactColor}44`,
                    transition:'width 0.8s ease',
                  }} />
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* ── Recommended Action ── */}
      <Card style={{ borderColor:'rgba(0,229,160,0.2)', background:'rgba(0,229,160,0.03)' }}>
        <SectionLabel>🤖 AI Recommended Action</SectionLabel>
        <p style={{ fontSize:15, lineHeight:1.7, marginTop:6, fontWeight:500 }}>{c.recommended}</p>
        <div style={{ display:'flex', gap:12, marginTop:18 }}>
          <Btn variant="danger" onClick={()=>setStatus('RESOLVED')}>⛔ Block Number</Btn>
          <Btn variant="ghost">📋 Add to Watchlist</Btn>
          <Btn variant="ghost">✉ Notify Network Ops</Btn>
          <Btn variant="ghost" style={{ marginLeft:'auto' }} onClick={()=>setStatus('DISMISSED')}>Dismiss Alert</Btn>
        </div>
      </Card>
    </div>
  );
}
