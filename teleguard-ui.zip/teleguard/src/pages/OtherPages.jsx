// ============================================================
//  Stage 6 — Subscriber Lookup
// ============================================================
import React, { useState } from 'react';
import { subscriberProfiles } from '../data/mockData';
import { FraudBadge, StatusPill, Card, PageHeader, Btn, SectionLabel } from '../components/UI';

export function SubscriberPage({ onNavigate }) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);

  const results = query.length > 2
    ? subscriberProfiles.filter(p => p.number.includes(query) || p.id.toLowerCase().includes(query.toLowerCase()) || p.name.toLowerCase().includes(query.toLowerCase()))
    : subscriberProfiles;

  const profile = selected || subscriberProfiles[0];

  return (
    <div style={{ padding:'32px 36px', maxWidth:1200 }}>
      <PageHeader title="Subscriber Lookup" subtitle="Search and risk-profile any subscriber account" />

      {/* Search bar */}
      <div style={{ display:'flex', gap:12, marginBottom:24 }}>
        <input
          value={query} onChange={e=>setQuery(e.target.value)}
          placeholder="🔍  Search by phone number, account ID, or name..."
          style={{ flex:1, background:'var(--bg-card)', border:'1px solid var(--border-dim)', borderRadius:10, padding:'13px 18px', color:'var(--text)', fontFamily:'var(--mono)', fontSize:14, outline:'none', transition:'border-color 0.2s' }}
          onFocus={e=>e.target.style.borderColor='var(--accent)'}
          onBlur={e=>e.target.style.borderColor='var(--border-dim)'}
        />
        <Btn variant="primary">Search</Btn>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'300px 1fr', gap:20 }}>
        {/* Results list */}
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          <SectionLabel>Results ({results.length})</SectionLabel>
          {results.map(p => (
            <div
              key={p.id}
              onClick={()=>setSelected(p)}
              style={{
                background: (selected||subscriberProfiles[0]).id===p.id ? 'var(--bg-hover)' : 'var(--bg-card)',
                border: `1px solid ${(selected||subscriberProfiles[0]).id===p.id ? 'var(--border)' : 'var(--border-dim)'}`,
                borderRadius:10, padding:'14px 16px', cursor:'pointer', transition:'all 0.15s',
              }}
              onMouseEnter={e=>{e.currentTarget.style.borderColor='var(--border)';}}
              onMouseLeave={e=>{if((selected||subscriberProfiles[0]).id!==p.id) e.currentTarget.style.borderColor='var(--border-dim)';}}
            >
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
                <span style={{ fontFamily:'var(--mono)', fontSize:13, fontWeight:700 }}>{p.number}</span>
                <StatusPill status={p.status} />
              </div>
              <div style={{ fontSize:12, color:'var(--muted)', marginBottom:8 }}>{p.id} · {p.network}</div>
              <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                {p.fraudFlags.map(f => <FraudBadge key={f} type={f} small />)}
                {p.fraudFlags.length === 0 && <span style={{ fontSize:11, color:'var(--accent)', fontFamily:'var(--mono)' }}>✓ No flags</span>}
              </div>
            </div>
          ))}
        </div>

        {/* Profile detail */}
        <div>
          <SectionLabel>Account Profile</SectionLabel>
          <Card style={{ marginBottom:16 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
              <div>
                <div style={{ fontSize:22, fontWeight:800, fontFamily:'var(--mono)' }}>{profile.number}</div>
                <div style={{ fontSize:13, color:'var(--muted)', marginTop:4 }}>{profile.id} · {profile.network}</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize:38, fontWeight:800, color: profile.riskScore > 70 ? '#ff4466' : profile.riskScore > 40 ? '#f59e0b' : '#00e5a0', letterSpacing:'-2px', lineHeight:1 }}>
                  {profile.riskScore}
                </div>
                <div style={{ fontSize:11, color:'var(--muted)', fontFamily:'var(--mono)', marginTop:3 }}>RISK SCORE</div>
              </div>
            </div>

            {/* Risk bar */}
            <div style={{ marginBottom:20 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                <span style={{ fontSize:12, color:'var(--muted)' }}>Risk Level</span>
                <span style={{ fontFamily:'var(--mono)', fontSize:11, color: profile.riskScore>70?'#ff4466':profile.riskScore>40?'#f59e0b':'#00e5a0', fontWeight:700 }}>
                  {profile.riskScore > 70 ? 'HIGH RISK' : profile.riskScore > 40 ? 'MEDIUM' : 'LOW RISK'}
                </span>
              </div>
              <div style={{ height:8, background:'var(--bg-hover)', borderRadius:4 }}>
                <div style={{ width:`${profile.riskScore}%`, height:'100%', background: profile.riskScore>70 ? '#ff4466' : profile.riskScore>40 ? '#f59e0b' : '#00e5a0', borderRadius:4, transition:'width 0.7s ease' }} />
              </div>
            </div>

            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
              {[
                ['Subscriber Name', profile.name],
                ['Status', profile.status],
                ['Total Calls', profile.activity.calls],
                ['SMS Sent', profile.activity.sms],
                ['Service Activations', profile.activity.activations],
                ['Active Fraud Flags', profile.fraudFlags.length || '—'],
              ].map(([l,v]) => (
                <div key={l}>
                  <div style={{ fontSize:11, color:'var(--muted)', fontFamily:'var(--mono)', textTransform:'uppercase', letterSpacing:'1px', marginBottom:3 }}>{l}</div>
                  <div style={{ fontSize:14, fontWeight:600 }}>{v}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Actions */}
          <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
            <Btn variant="ghost">📊 View Activity Log</Btn>
            <Btn variant="ghost" onClick={()=>onNavigate('case')}>🔍 Open Investigation</Btn>
            <Btn variant="ghost">📋 Add to Watchlist</Btn>
            {profile.status === 'FLAGGED' && <Btn variant="danger">⛔ Block Account</Btn>}
          </div>
        </div>
      </div>
    </div>
  );
}


// ============================================================
//  Stage 7 — Audit Log
// ============================================================
import { auditLog } from '../data/mockData';

export function AuditPage() {
  return (
    <div style={{ padding:'32px 36px', maxWidth:1100 }}>
      <PageHeader title="Audit Log" subtitle="Complete record of all administrator actions in the system">
        <Btn variant="ghost" small>⬇ Export Log</Btn>
      </PageHeader>

      <Card style={{ padding:0, overflow:'hidden' }}>
        {/* Header */}
        <div style={{
          display:'grid', gridTemplateColumns:'80px 220px 1fr 100px 140px',
          gap:16, padding:'12px 24px',
          background:'var(--bg-surface)', borderBottom:'1px solid var(--border-dim)',
        }}>
          {['ID','ADMIN','ACTION','TIME','IP ADDRESS'].map(h => (
            <span key={h} style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'1.5px' }}>{h}</span>
          ))}
        </div>

        {auditLog.map((log, i) => (
          <div key={log.id} style={{
            display:'grid', gridTemplateColumns:'80px 220px 1fr 100px 140px',
            gap:16, alignItems:'center', padding:'14px 24px',
            borderBottom: i < auditLog.length-1 ? '1px solid var(--border-dim)' : 'none',
            transition:'background 0.15s',
          }}
          onMouseEnter={e=>e.currentTarget.style.background='var(--bg-hover)'}
          onMouseLeave={e=>e.currentTarget.style.background='transparent'}
          >
            <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)' }}>{log.id}</span>
            <div>
              <div style={{ fontSize:13, fontWeight:600 }}>{log.admin.split('@')[0]}</div>
              <div style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)' }}>{log.admin}</div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <span style={{
                display:'inline-block', width:8, height:8, borderRadius:'50%', flexShrink:0,
                background: log.action.includes('RESOLVED') ? 'var(--accent)' : log.action.includes('BLOCK') ? '#ff4466' : log.action.includes('LOGIN') ? 'var(--accent2)' : '#f59e0b',
              }}/>
              <span style={{ fontSize:13 }}>{log.action}</span>
            </div>
            <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)' }}>{log.time}</span>
            <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)' }}>{log.ip}</span>
          </div>
        ))}
      </Card>
    </div>
  );
}


// ============================================================
//  Stage 8 — Settings
// ============================================================
export function SettingsPage() {
  const [thresholds, setThresholds] = useState({ SIM:80, SMS:75, SUB:70, WAN:85 });
  const [saved, setSaved] = useState(false);

  const save = () => { setSaved(true); setTimeout(()=>setSaved(false), 2500); };

  return (
    <div style={{ padding:'32px 36px', maxWidth:900 }}>
      <PageHeader title="System Settings" subtitle="Configure detection thresholds, alerts, and user access">
        {saved && (
          <div style={{ background:'rgba(0,229,160,0.12)', border:'1px solid rgba(0,229,160,0.3)', borderRadius:8, padding:'8px 16px', fontSize:13, color:'var(--accent)', fontFamily:'var(--mono)' }}>
            ✓ Settings saved
          </div>
        )}
        <Btn variant="primary" onClick={save}>Save Changes</Btn>
      </PageHeader>

      {/* Detection Thresholds */}
      <Card style={{ marginBottom:20 }}>
        <SectionLabel>Detection Thresholds</SectionLabel>
        <p style={{ fontSize:13, color:'var(--muted)', marginBottom:20, marginTop:4 }}>
          Minimum confidence score (%) required to trigger an alert for each fraud type.
        </p>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24 }}>
          {[['SIM','⚡ SIM Box Fraud','var(--sim)'],['SMS','✉️ Smishing','var(--sms)'],['SUB','🔑 Subscription Fraud','var(--sub)'],['WAN','📞 Wangiri Fraud','var(--wan)']].map(([key,label,color]) => (
            <div key={key}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
                <span style={{ fontSize:14, fontWeight:600 }}>{label}</span>
                <span style={{ fontFamily:'var(--mono)', fontSize:14, fontWeight:800, color }}>{thresholds[key]}%</span>
              </div>
              <input type="range" min={50} max={99} value={thresholds[key]}
                onChange={e=>setThresholds(t=>({...t,[key]:+e.target.value}))}
                style={{ width:'100%', accentColor:color, height:4 }}
              />
              <div style={{ display:'flex', justifyContent:'space-between', marginTop:4 }}>
                <span style={{ fontSize:10, color:'var(--muted)', fontFamily:'var(--mono)' }}>50%</span>
                <span style={{ fontSize:10, color:'var(--muted)', fontFamily:'var(--mono)' }}>99%</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Notification Settings */}
      <Card style={{ marginBottom:20 }}>
        <SectionLabel>Notification Channels</SectionLabel>
        <div style={{ display:'flex', flexDirection:'column', gap:14, marginTop:8 }}>
          {[
            { label:'Dashboard alerts (real-time)', enabled:true  },
            { label:'Email notifications (critical only)', enabled:true  },
            { label:'SMS notifications to admin phones', enabled:false },
            { label:'Slack / Teams webhook integration', enabled:false },
          ].map((item, i) => (
            <label key={i} style={{ display:'flex', alignItems:'center', gap:14, cursor:'pointer', padding:'12px 14px', background:'var(--bg-hover)', borderRadius:8 }}>
              <input type="checkbox" defaultChecked={item.enabled} style={{ accentColor:'var(--accent)', width:15, height:15 }} />
              <span style={{ fontSize:14 }}>{item.label}</span>
            </label>
          ))}
        </div>
      </Card>

      {/* Admin Users */}
      <Card>
        <SectionLabel>Admin Users</SectionLabel>
        <div style={{ display:'flex', flexDirection:'column', gap:10, marginTop:8 }}>
          {[
            { name:'Admin User',   email:'admin@teleguard.net',    role:'Super Admin', active:true  },
            { name:'Analyst One',  email:'analyst@teleguard.net',  role:'Fraud Analyst',active:true  },
            { name:'Viewer User',  email:'viewer@teleguard.net',   role:'Read Only',   active:false },
          ].map((u,i) => (
            <div key={i} style={{ display:'flex', alignItems:'center', gap:14, padding:'12px 16px', background:'var(--bg-hover)', borderRadius:8 }}>
              <div style={{ width:36, height:36, borderRadius:'50%', background:'linear-gradient(135deg,var(--accent),var(--accent2))', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, color:'#07090f', fontSize:14, flexShrink:0 }}>
                {u.name[0]}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14, fontWeight:700 }}>{u.name}</div>
                <div style={{ fontSize:11, color:'var(--muted)', fontFamily:'var(--mono)' }}>{u.email}</div>
              </div>
              <span style={{ fontSize:12, color:'var(--muted)', background:'var(--bg-card)', borderRadius:6, padding:'4px 12px' }}>{u.role}</span>
              <span style={{ width:8, height:8, borderRadius:'50%', background: u.active ? 'var(--accent)' : 'var(--muted)', flexShrink:0 }} />
            </div>
          ))}
        </div>
        <div style={{ marginTop:14 }}>
          <Btn variant="outline" small>+ Invite Admin User</Btn>
        </div>
      </Card>
    </div>
  );
}
