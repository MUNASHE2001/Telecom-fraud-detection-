// ============================================================
//  Stage 1 — Login Page
// ============================================================
import React, { useState } from 'react';

export default function LoginPage({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = () => {
    setError('');
    if (!email || !password) { setError('Please enter your email and password.'); return; }
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 1400);
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex',
      background: 'var(--bg-base)', overflow: 'hidden', position: 'relative',
    }}>
      {/* Animated grid */}
      <style>{`
        @keyframes gridMove { 0%{background-position:0 0} 100%{background-position:48px 48px} }
        @keyframes floatOrb { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-28px)} }
        @keyframes fadeSlideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes fadeSlideLeft { from{opacity:0;transform:translateX(20px)} to{opacity:1;transform:translateX(0)} }
        @keyframes pulse2 {0%{box-shadow:0 0 0 0 rgba(0,229,160,0.4)}70%{box-shadow:0 0 0 10px transparent}100%{box-shadow:0 0 0 0 transparent}}
        .login-input:focus { border-color: var(--accent) !important; box-shadow: 0 0 0 3px rgba(0,229,160,0.12) !important; outline: none; }
        .login-btn:hover { opacity: 0.88; transform: translateY(-1px); }
        .login-btn:active { transform: translateY(0); }
      `}</style>

      <div style={{
        position: 'fixed', inset: 0, zIndex: 0,
        backgroundImage: 'linear-gradient(rgba(0,229,160,0.035) 1px,transparent 1px),linear-gradient(90deg,rgba(0,229,160,0.035) 1px,transparent 1px)',
        backgroundSize: '48px 48px',
        animation: 'gridMove 18s linear infinite',
      }} />
      <div style={{ position:'fixed', width:600, height:600, borderRadius:'50%', background:'rgba(0,229,160,0.05)', filter:'blur(110px)', top:-200, right:-100, animation:'floatOrb 14s ease-in-out infinite', zIndex:0, pointerEvents:'none' }} />
      <div style={{ position:'fixed', width:500, height:500, borderRadius:'50%', background:'rgba(0,170,255,0.04)', filter:'blur(100px)', bottom:-150, left:-80, animation:'floatOrb 18s ease-in-out infinite reverse', zIndex:0, pointerEvents:'none' }} />

      {/* ── LEFT — Brand Panel ── */}
      <div style={{
        position: 'relative', zIndex: 1,
        width: '56%', display: 'flex', flexDirection: 'column',
        justifyContent: 'center', padding: '60px 80px',
        borderRight: '1px solid var(--border-dim)',
        animation: 'fadeSlideUp 0.7s ease both',
      }}>
        {/* Logo */}
        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:56 }}>
          <div style={{ width:50, height:50, background:'linear-gradient(135deg,var(--accent),var(--accent2))', borderRadius:13, display:'flex', alignItems:'center', justifyContent:'center', fontSize:24 }}>🛡</div>
          <div>
            <div style={{ fontWeight:800, fontSize:28, letterSpacing:'-0.5px' }}>
              Tele<span style={{ color:'var(--accent)' }}>Guard</span>
            </div>
            <div style={{ fontSize:10, color:'var(--muted)', fontFamily:'var(--mono)', letterSpacing:'2px', marginTop:2 }}>
              AI FRAUD DETECTION PLATFORM
            </div>
          </div>
        </div>

        {/* Tag */}
        <div style={{ display:'inline-flex', alignItems:'center', gap:8, marginBottom:20, background:'rgba(0,229,160,0.08)', border:'1px solid var(--border)', borderRadius:6, padding:'6px 14px', width:'fit-content' }}>
          <span style={{ width:7, height:7, borderRadius:'50%', background:'var(--accent)', animation:'pulse2 2s infinite', display:'inline-block' }} />
          <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--accent)', letterSpacing:'2px' }}>SYSTEM ONLINE</span>
        </div>

        <h1 style={{ fontSize:50, fontWeight:800, lineHeight:1.1, letterSpacing:'-2px', marginBottom:20 }}>
          Detect Fraud.<br />
          <span style={{ background:'linear-gradient(90deg, var(--accent), var(--accent2))', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
            Protect Networks.
          </span><br />
          Act in Real Time.
        </h1>
        <p style={{ color:'var(--muted)', fontSize:15, lineHeight:1.75, maxWidth:440, marginBottom:44 }}>
          An AI-powered surveillance system that monitors call detail records, SMS logs, and subscription events — detecting SIM Box, Smishing, Subscription, and Wangiri fraud with machine learning.
        </p>

        {/* Stats */}
        <div style={{ display:'flex', gap:40, marginBottom:44 }}>
          {[['4','Fraud Types'],['ML','Powered Engine'],['~0ms','Alert Latency']].map(([v,l]) => (
            <div key={l}>
              <div style={{ fontSize:30, fontWeight:800, color:'var(--accent)', letterSpacing:'-1px' }}>{v}</div>
              <div style={{ fontSize:11, fontFamily:'var(--mono)', color:'var(--muted)', letterSpacing:'1px', textTransform:'uppercase', marginTop:3 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Fraud type badges */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
          {[
            ['⚡','SIM Box Fraud','var(--sim)','var(--sim-bg)'],
            ['✉️','Smishing','var(--sms)','var(--sms-bg)'],
            ['🔑','Subscription Fraud','var(--sub)','var(--sub-bg)'],
            ['📞','Wangiri Fraud','var(--wan)','var(--wan-bg)'],
          ].map(([icon,label,color,bg]) => (
            <span key={label} style={{ display:'inline-flex', alignItems:'center', gap:6, background:bg, color, border:`1px solid ${color}33`, borderRadius:6, padding:'7px 14px', fontSize:12, fontFamily:'var(--mono)', fontWeight:700 }}>
              {icon} {label}
            </span>
          ))}
        </div>
      </div>

      {/* ── RIGHT — Login Form ── */}
      <div style={{
        position:'relative', zIndex:1,
        width:'44%', display:'flex', alignItems:'center', justifyContent:'center',
        padding:'60px 60px',
        animation:'fadeSlideLeft 0.7s ease 0.15s both',
      }}>
        <div style={{ width:'100%', maxWidth:390 }}>
          <div style={{ marginBottom:36 }}>
            <h2 style={{ fontSize:28, fontWeight:800, letterSpacing:'-0.5px' }}>Admin Sign In</h2>
            <p style={{ color:'var(--muted)', fontSize:14, marginTop:6 }}>Access the fraud detection dashboard</p>
          </div>

          {error && (
            <div style={{ background:'rgba(255,68,102,0.1)', border:'1px solid rgba(255,68,102,0.3)', borderRadius:8, padding:'11px 16px', fontSize:13, color:'#ff4466', marginBottom:18 }}>
              ⚠ {error}
            </div>
          )}

          {/* Email */}
          <div style={{ marginBottom:18 }}>
            <label style={{ display:'block', fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'2px', marginBottom:8 }}>
              Admin Email
            </label>
            <input
              type="email" value={email} onChange={e=>setEmail(e.target.value)}
              placeholder="admin@teleguard.net"
              className="login-input"
              style={{ width:'100%', background:'var(--bg-card)', border:'1px solid var(--border-dim)', borderRadius:8, padding:'13px 16px', color:'var(--text)', fontFamily:'var(--mono)', fontSize:14, transition:'border-color 0.2s, box-shadow 0.2s' }}
            />
          </div>

          {/* Password */}
          <div style={{ marginBottom:22 }}>
            <label style={{ display:'block', fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'2px', marginBottom:8 }}>
              Password
            </label>
            <input
              type="password" value={password} onChange={e=>setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="login-input"
              onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              style={{ width:'100%', background:'var(--bg-card)', border:'1px solid var(--border-dim)', borderRadius:8, padding:'13px 16px', color:'var(--text)', fontFamily:'var(--mono)', fontSize:14, transition:'border-color 0.2s, box-shadow 0.2s' }}
            />
          </div>

          {/* Remember + Forgot */}
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:26 }}>
            <label style={{ display:'flex', alignItems:'center', gap:8, fontSize:13, color:'var(--muted)', cursor:'pointer' }}>
              <input type="checkbox" style={{ accentColor:'var(--accent)' }} /> Keep me signed in
            </label>
            <a href="#" style={{ fontSize:13, color:'var(--accent)', fontFamily:'var(--mono)', textDecoration:'none' }}>
              Forgot password?
            </a>
          </div>

          {/* Login button */}
          <button
            className="login-btn"
            onClick={handleSubmit}
            disabled={loading}
            style={{
              width:'100%', background:'linear-gradient(135deg, var(--accent), var(--accent2))',
              border:'none', borderRadius:9, padding:'15px',
              color:'#07090f', fontFamily:'var(--font)', fontSize:15, fontWeight:800,
              cursor:'pointer', letterSpacing:'0.3px',
              boxShadow:'0 4px 28px rgba(0,229,160,0.25)',
              transition:'opacity 0.15s, transform 0.15s',
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? '⏳  Authenticating...' : 'Access Dashboard →'}
          </button>

          {/* Divider */}
          <div style={{ display:'flex', alignItems:'center', gap:14, margin:'24px 0' }}>
            <div style={{ flex:1, height:1, background:'var(--border-dim)' }} />
            <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)' }}>OR</span>
            <div style={{ flex:1, height:1, background:'var(--border-dim)' }} />
          </div>

          {/* SSO */}
          <button style={{
            width:'100%', background:'transparent', border:'1px solid var(--border-dim)',
            borderRadius:9, padding:'13px', color:'var(--text)',
            fontFamily:'var(--font)', fontSize:14, fontWeight:600, cursor:'pointer',
            display:'flex', alignItems:'center', justifyContent:'center', gap:10,
            transition:'border-color 0.2s, background 0.2s',
          }}
          onMouseEnter={e=>{e.currentTarget.style.borderColor='var(--accent2)';e.currentTarget.style.background='rgba(0,170,255,0.05)'}}
          onMouseLeave={e=>{e.currentTarget.style.borderColor='var(--border-dim)';e.currentTarget.style.background='transparent'}}
          >
            🏢 &nbsp;Sign in with SSO / LDAP
          </button>

          {/* Security note */}
          <div style={{ marginTop:28, display:'flex', gap:10, padding:'13px 14px', background:'rgba(0,229,160,0.04)', border:'1px solid rgba(0,229,160,0.1)', borderRadius:8 }}>
            <span style={{ fontSize:15, flexShrink:0 }}>🔒</span>
            <p style={{ fontSize:12, color:'var(--muted)', lineHeight:1.6 }}>
              This system is restricted to authorised network administrators and fraud analysts only. All access is logged and audited.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
