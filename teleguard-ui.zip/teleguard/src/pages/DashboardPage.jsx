// ============================================================
//  Stage 2 — Main Dashboard
// ============================================================
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import { kpiData, liveAlerts, fraudTrend, fraudDistribution } from '../data/mockData';
import { FraudBadge, SeverityBadge, StatusPill, ConfidenceBar, Card, PageHeader, LiveDot, Btn } from '../components/UI';

const KPI_CONFIG = [
  { key:'totalAlerts',   label:'Total Alerts Today',  icon:'🔔', accent:'var(--wan)'    },
  { key:'activeThreats', label:'Active Threats',       icon:'⚡', accent:'var(--sim)'    },
  { key:'resolvedToday', label:'Resolved Today',       icon:'✅', accent:'var(--accent)' },
  { key:'falsePositives',label:'False Positive Rate',  icon:'🎯', accent:'var(--sms)',  suffix:'%' },
];

export default function DashboardPage({ onNavigate }) {
  return (
    <div style={{ padding:'32px 36px', maxWidth:1300 }}>
      <PageHeader
        title="Overview Dashboard"
        subtitle="Real-time fraud monitoring across all 4 fraud categories"
      >
        <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 14px', background:'rgba(0,229,160,0.07)', border:'1px solid var(--border)', borderRadius:8 }}>
          <LiveDot />
          <span style={{ fontSize:12, fontFamily:'var(--mono)', color:'var(--accent)', letterSpacing:'0.5px' }}>Live Feed</span>
        </div>
        <Btn variant="ghost" small onClick={()=>onNavigate('alerts')}>View All Alerts →</Btn>
      </PageHeader>

      {/* ── KPI Cards ── */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:28 }}>
        {KPI_CONFIG.map(cfg => {
          const d = kpiData[cfg.key];
          return (
            <Card key={cfg.key} style={{ position:'relative', overflow:'hidden' }}>
              <div style={{ position:'absolute', top:0, left:0, width:'100%', height:3, background:cfg.accent, borderRadius:'12px 12px 0 0', opacity:0.7 }} />
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:14 }}>
                <span style={{ fontSize:22 }}>{cfg.icon}</span>
                <span style={{
                  fontFamily:'var(--mono)', fontSize:11, fontWeight:700,
                  color: d.up ? 'var(--accent)' : '#ff4466',
                  background: d.up ? 'rgba(0,229,160,0.1)' : 'rgba(255,68,102,0.1)',
                  padding:'3px 9px', borderRadius:20,
                }}>
                  {d.delta}
                </span>
              </div>
              <div style={{ fontSize:32, fontWeight:800, letterSpacing:'-1px', color:cfg.accent }}>
                {d.value}{cfg.suffix||''}
              </div>
              <div style={{ fontSize:12, color:'var(--muted)', marginTop:5 }}>{cfg.label}</div>
            </Card>
          );
        })}
      </div>

      {/* ── Charts row ── */}
      <div style={{ display:'grid', gridTemplateColumns:'1.6fr 1fr', gap:20, marginBottom:28 }}>

        {/* Trend chart */}
        <Card>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
            <div>
              <div style={{ fontWeight:700, fontSize:15 }}>Fraud Activity — Last 7 Days</div>
              <div style={{ fontSize:12, color:'var(--muted)', marginTop:3 }}>Alerts by fraud type per day</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={fraudTrend} margin={{ top:5, right:5, bottom:0, left:-20 }}>
              <defs>
                {[['WAN','#ff4466'],['SMS','#a78bfa'],['SIM','#f59e0b'],['SUB','#00aaff']].map(([k,c])=>(
                  <linearGradient key={k} id={`g${k}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={c} stopOpacity={0.2}/>
                    <stop offset="95%" stopColor={c} stopOpacity={0}/>
                  </linearGradient>
                ))}
              </defs>
              <XAxis dataKey="day" tick={{ fill:'#5b6f8a', fontSize:11, fontFamily:'Space Mono' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:'#5b6f8a', fontSize:11, fontFamily:'Space Mono' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background:'#111827', border:'1px solid rgba(0,229,160,0.2)', borderRadius:8, fontFamily:'Space Mono', fontSize:12 }} />
              <Area type="monotone" dataKey="WAN" stroke="#ff4466" fill="url(#gWAN)" strokeWidth={2} dot={false} />
              <Area type="monotone" dataKey="SMS" stroke="#a78bfa" fill="url(#gSMS)" strokeWidth={2} dot={false} />
              <Area type="monotone" dataKey="SIM" stroke="#f59e0b" fill="url(#gSIM)" strokeWidth={2} dot={false} />
              <Area type="monotone" dataKey="SUB" stroke="#00aaff" fill="url(#gSUB)" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
          {/* Legend */}
          <div style={{ display:'flex', gap:18, marginTop:12 }}>
            {[['Wangiri','#ff4466'],['Smishing','#a78bfa'],['SIM Box','#f59e0b'],['Subscription','#00aaff']].map(([l,c])=>(
              <div key={l} style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, color:'var(--muted)' }}>
                <span style={{ width:10, height:3, background:c, borderRadius:2, display:'inline-block' }} />
                {l}
              </div>
            ))}
          </div>
        </Card>

        {/* Distribution bars */}
        <Card>
          <div style={{ fontWeight:700, fontSize:15, marginBottom:4 }}>Fraud Distribution</div>
          <div style={{ fontSize:12, color:'var(--muted)', marginBottom:20 }}>Share by type (this month)</div>
          {fraudDistribution.map(item => {
            const colors = { 'Wangiri':'#ff4466','Smishing':'#a78bfa','SIM Box':'#f59e0b','Subscription':'#00aaff' };
            const c = colors[item.name] || 'var(--accent)';
            return (
              <div key={item.name} style={{ marginBottom:16 }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                  <span style={{ fontSize:13, fontWeight:600 }}>{item.name}</span>
                  <span style={{ fontFamily:'var(--mono)', fontSize:12, color:c, fontWeight:700 }}>{item.value}%</span>
                </div>
                <div style={{ height:6, background:'var(--bg-hover)', borderRadius:3, overflow:'hidden' }}>
                  <div style={{ width:`${item.value}%`, height:'100%', background:c, borderRadius:3, boxShadow:`0 0 10px ${c}66`, transition:'width 0.8s ease' }} />
                </div>
              </div>
            );
          })}
        </Card>
      </div>

      {/* ── Live Alert Feed ── */}
      <Card style={{ padding:0 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'18px 24px', borderBottom:'1px solid var(--border-dim)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <LiveDot />
            <span style={{ fontWeight:700, fontSize:15 }}>Live Alert Feed</span>
            <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)', marginLeft:4 }}>8 recent</span>
          </div>
          <Btn variant="outline" small onClick={()=>onNavigate('alerts')}>View All</Btn>
        </div>
        <div>
          {liveAlerts.map((alert, i) => (
            <div
              key={alert.id}
              onClick={()=>onNavigate('case')}
              style={{
                display:'grid', gridTemplateColumns:'80px 1fr 140px 130px 100px 100px',
                alignItems:'center', gap:16, padding:'13px 24px',
                borderBottom: i < liveAlerts.length-1 ? '1px solid var(--border-dim)' : 'none',
                cursor:'pointer', transition:'background 0.15s',
              }}
              onMouseEnter={e=>e.currentTarget.style.background='var(--bg-hover)'}
              onMouseLeave={e=>e.currentTarget.style.background='transparent'}
            >
              <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)' }}>{alert.id}</span>
              <FraudBadge type={alert.type} small />
              <span style={{ fontFamily:'var(--mono)', fontSize:12 }}>{alert.number}</span>
              <ConfidenceBar value={alert.confidence} />
              <SeverityBadge level={alert.severity} />
              <StatusPill status={alert.status} />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
