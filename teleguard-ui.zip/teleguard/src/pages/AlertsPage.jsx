// ============================================================
//  Stage 3 — Alerts Center
// ============================================================
import React, { useState } from 'react';
import { allAlerts } from '../data/mockData';
import { FraudBadge, SeverityBadge, StatusPill, ConfidenceBar, Card, PageHeader, Btn } from '../components/UI';

const FILTERS = ['ALL','SIM','SMS','SUB','WAN'];
const STATUS_FILTERS = ['ALL','OPEN','INVESTIGATING','RESOLVED','DISMISSED'];

export default function AlertsPage({ onNavigate }) {
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [search, setSearch] = useState('');

  const filtered = allAlerts.filter(a => {
    const matchType   = typeFilter   === 'ALL' || a.type   === typeFilter;
    const matchStatus = statusFilter === 'ALL' || a.status === statusFilter;
    const matchSearch = !search || a.number.includes(search) || a.id.toLowerCase().includes(search.toLowerCase());
    return matchType && matchStatus && matchSearch;
  });

  const counts = { ALL:allAlerts.length };
  allAlerts.forEach(a => { counts[a.type] = (counts[a.type]||0)+1; });

  return (
    <div style={{ padding:'32px 36px', maxWidth:1300 }}>
      <PageHeader title="Alerts Center" subtitle={`${filtered.length} alerts matching current filters`}>
        <Btn variant="ghost" small>⬇ Export CSV</Btn>
        <Btn variant="primary" small>+ Manual Report</Btn>
      </PageHeader>

      {/* ── Summary stat row ── */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:24 }}>
        {[
          { label:'Open',          count: allAlerts.filter(a=>a.status==='OPEN').length,          color:'#ff4466' },
          { label:'Investigating', count: allAlerts.filter(a=>a.status==='INVESTIGATING').length,  color:'#f59e0b' },
          { label:'Resolved',      count: allAlerts.filter(a=>a.status==='RESOLVED').length,       color:'#00e5a0' },
          { label:'Dismissed',     count: allAlerts.filter(a=>a.status==='DISMISSED').length,      color:'#5b6f8a' },
        ].map(s => (
          <div key={s.label} style={{ background:'var(--bg-card)', border:`1px solid ${s.color}22`, borderRadius:10, padding:'14px 18px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ fontSize:13, color:'var(--muted)' }}>{s.label}</span>
            <span style={{ fontSize:22, fontWeight:800, color:s.color, fontFamily:'var(--mono)' }}>{s.count}</span>
          </div>
        ))}
      </div>

      {/* ── Filters ── */}
      <Card style={{ padding:'16px 20px', marginBottom:20 }}>
        <div style={{ display:'flex', flexWrap:'wrap', gap:16, alignItems:'center' }}>
          {/* Search */}
          <input
            value={search} onChange={e=>setSearch(e.target.value)}
            placeholder="🔍  Search by number or alert ID..."
            style={{ flex:1, minWidth:200, background:'var(--bg-hover)', border:'1px solid var(--border-dim)', borderRadius:8, padding:'9px 14px', color:'var(--text)', fontFamily:'var(--mono)', fontSize:13, outline:'none' }}
          />

          {/* Type filter */}
          <div style={{ display:'flex', gap:6 }}>
            {FILTERS.map(f => (
              <button key={f} onClick={()=>setTypeFilter(f)} style={{
                padding:'7px 14px', borderRadius:7, border:'1px solid',
                borderColor: typeFilter===f ? 'var(--accent)' : 'var(--border-dim)',
                background: typeFilter===f ? 'rgba(0,229,160,0.1)' : 'transparent',
                color: typeFilter===f ? 'var(--accent)' : 'var(--muted)',
                fontFamily:'var(--mono)', fontSize:11, fontWeight:700, cursor:'pointer',
                letterSpacing:'0.5px',
              }}>
                {f} {counts[f] ? `(${counts[f]})` : ''}
              </button>
            ))}
          </div>

          {/* Status filter */}
          <div style={{ display:'flex', gap:6 }}>
            {STATUS_FILTERS.map(f => (
              <button key={f} onClick={()=>setStatusFilter(f)} style={{
                padding:'7px 14px', borderRadius:7, border:'1px solid',
                borderColor: statusFilter===f ? 'var(--accent2)' : 'var(--border-dim)',
                background: statusFilter===f ? 'rgba(0,170,255,0.1)' : 'transparent',
                color: statusFilter===f ? 'var(--accent2)' : 'var(--muted)',
                fontFamily:'var(--mono)', fontSize:11, fontWeight:700, cursor:'pointer',
              }}>
                {f}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {/* ── Alerts Table ── */}
      <Card style={{ padding:0, overflow:'hidden' }}>
        {/* Table header */}
        <div style={{
          display:'grid', gridTemplateColumns:'80px 130px 170px 1fr 130px 130px 100px',
          gap:12, padding:'12px 24px',
          background:'var(--bg-surface)', borderBottom:'1px solid var(--border-dim)',
        }}>
          {['ALERT ID','TYPE','NUMBER','CONFIDENCE','SEVERITY','STATUS','ACTION'].map(h => (
            <span key={h} style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'1.5px' }}>{h}</span>
          ))}
        </div>

        {filtered.length === 0 && (
          <div style={{ padding:40, textAlign:'center', color:'var(--muted)', fontSize:14 }}>
            No alerts match your current filters.
          </div>
        )}

        {filtered.map((alert, i) => (
          <div
            key={alert.id}
            style={{
              display:'grid', gridTemplateColumns:'80px 130px 170px 1fr 130px 130px 100px',
              gap:12, alignItems:'center', padding:'14px 24px',
              borderBottom: i < filtered.length-1 ? '1px solid var(--border-dim)' : 'none',
              cursor:'pointer', transition:'background 0.15s',
            }}
            onMouseEnter={e=>e.currentTarget.style.background='var(--bg-hover)'}
            onMouseLeave={e=>e.currentTarget.style.background='transparent'}
            onClick={()=>onNavigate('case')}
          >
            <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)' }}>{alert.id}</span>
            <FraudBadge type={alert.type} small />
            <span style={{ fontFamily:'var(--mono)', fontSize:12 }}>{alert.number}</span>
            <ConfidenceBar value={alert.confidence} />
            <SeverityBadge level={alert.severity} />
            <StatusPill status={alert.status} />
            <Btn variant="ghost" small onClick={e=>{e.stopPropagation();onNavigate('case');}}>
              View →
            </Btn>
          </div>
        ))}
      </Card>
    </div>
  );
}
