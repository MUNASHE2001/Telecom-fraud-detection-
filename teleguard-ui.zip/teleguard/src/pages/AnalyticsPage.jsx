// ============================================================
//  Stage 5 — Analytics & Reports
// ============================================================
import React, { useState } from 'react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { fraudTrend, monthlyStats, fraudDistribution, FRAUD_TYPES } from '../data/mockData';
import { Card, PageHeader, Btn, SectionLabel } from '../components/UI';

const PERIOD_OPTIONS = ['Last 7 Days','Last 30 Days','Last 3 Months','Custom'];
const PIE_COLORS = ['#ff4466','#a78bfa','#f59e0b','#00aaff'];

export default function AnalyticsPage() {
  const [period, setPeriod] = useState('Last 7 Days');

  return (
    <div style={{ padding:'32px 36px', maxWidth:1300 }}>
      <PageHeader title="Analytics & Reports" subtitle="Fraud trends, model performance, and financial impact">
        {/* Period selector */}
        <div style={{ display:'flex', gap:4, background:'var(--bg-surface)', border:'1px solid var(--border-dim)', borderRadius:9, padding:4 }}>
          {PERIOD_OPTIONS.map(p => (
            <button key={p} onClick={()=>setPeriod(p)} style={{
              padding:'7px 14px', borderRadius:7, border:'none', cursor:'pointer',
              background: period===p ? 'var(--bg-card)' : 'transparent',
              color: period===p ? 'var(--text)' : 'var(--muted)',
              fontFamily:'var(--font)', fontSize:12, fontWeight:600,
              boxShadow: period===p ? '0 1px 4px rgba(0,0,0,0.3)' : 'none',
              transition:'all 0.15s',
            }}>{p}</button>
          ))}
        </div>
        <Btn variant="ghost" small>⬇ Export Report</Btn>
      </PageHeader>

      {/* ── Model Performance KPIs ── */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:28 }}>
        {[
          { label:'Precision',    value:'94.2%', sub:'Across all 4 types', color:'var(--accent)'  },
          { label:'Recall',       value:'91.7%', sub:'True positive rate',  color:'var(--accent2)' },
          { label:'F1 Score',     value:'92.9%', sub:'Harmonic mean',       color:'var(--sms)'     },
          { label:'False Pos. Rate', value:'2.4%', sub:'vs 11.2% baseline',  color:'var(--sim)'     },
        ].map(m => (
          <Card key={m.label} style={{ textAlign:'center', padding:'22px 18px' }}>
            <div style={{ fontSize:32, fontWeight:800, color:m.color, letterSpacing:'-1px', marginBottom:6 }}>{m.value}</div>
            <div style={{ fontSize:14, fontWeight:700 }}>{m.label}</div>
            <div style={{ fontSize:11, color:'var(--muted)', marginTop:4 }}>{m.sub}</div>
          </Card>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.5fr 1fr', gap:20, marginBottom:20 }}>
        {/* Monthly total chart */}
        <Card>
          <SectionLabel>Total Fraud Alerts — Monthly</SectionLabel>
          <div style={{ fontSize:15, fontWeight:700, marginBottom:16 }}>Detection Volume Trend</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyStats} margin={{ top:5, right:5, bottom:0, left:-20 }}>
              <XAxis dataKey="month" tick={{ fill:'#5b6f8a', fontSize:11, fontFamily:'Space Mono' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:'#5b6f8a', fontSize:11, fontFamily:'Space Mono' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background:'#111827', border:'1px solid rgba(0,229,160,0.2)', borderRadius:8, fontFamily:'Space Mono', fontSize:12 }} />
              <Bar dataKey="total" radius={[5,5,0,0]}>
                {monthlyStats.map((_, i) => (
                  <Cell key={i} fill={i === monthlyStats.length-1 ? 'var(--accent)' : '#1e3048'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Pie chart */}
        <Card>
          <SectionLabel>Fraud Type Split</SectionLabel>
          <div style={{ fontSize:15, fontWeight:700, marginBottom:10 }}>Distribution by Category</div>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={fraudDistribution} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={4} dataKey="value">
                {fraudDistribution.map((_, i) => <Cell key={i} fill={PIE_COLORS[i]} />)}
              </Pie>
              <Tooltip contentStyle={{ background:'#111827', border:'1px solid rgba(0,229,160,0.2)', borderRadius:8, fontFamily:'Space Mono', fontSize:12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginTop:8 }}>
            {fraudDistribution.map((item,i) => (
              <div key={item.name} style={{ display:'flex', alignItems:'center', gap:8, fontSize:12 }}>
                <span style={{ width:10, height:10, borderRadius:3, background:PIE_COLORS[i], display:'inline-block', flexShrink:0 }} />
                <span style={{ color:'var(--muted)' }}>{item.name}</span>
                <span style={{ fontFamily:'var(--mono)', fontWeight:700, marginLeft:'auto', color:PIE_COLORS[i] }}>{item.value}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* ── 7-day area chart ── */}
      <Card style={{ marginBottom:20 }}>
        <SectionLabel>Fraud Activity by Type — 7 Day Breakdown</SectionLabel>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={fraudTrend} margin={{ top:5, right:10, bottom:0, left:-20 }}>
            <defs>
              {[['WAN','#ff4466'],['SMS','#a78bfa'],['SIM','#f59e0b'],['SUB','#00aaff']].map(([k,c])=>(
                <linearGradient key={k} id={`ag${k}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={c} stopOpacity={0.18}/>
                  <stop offset="95%" stopColor={c} stopOpacity={0}/>
                </linearGradient>
              ))}
            </defs>
            <XAxis dataKey="day" tick={{ fill:'#5b6f8a', fontSize:11, fontFamily:'Space Mono' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill:'#5b6f8a', fontSize:11, fontFamily:'Space Mono' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background:'#111827', border:'1px solid rgba(0,229,160,0.2)', borderRadius:8, fontFamily:'Space Mono', fontSize:12 }} />
            <Area type="monotone" dataKey="WAN" name="Wangiri"      stroke="#ff4466" fill="url(#agWAN)" strokeWidth={2.5} dot={false} />
            <Area type="monotone" dataKey="SMS" name="Smishing"     stroke="#a78bfa" fill="url(#agSMS)" strokeWidth={2.5} dot={false} />
            <Area type="monotone" dataKey="SIM" name="SIM Box"      stroke="#f59e0b" fill="url(#agSIM)" strokeWidth={2.5} dot={false} />
            <Area type="monotone" dataKey="SUB" name="Subscription" stroke="#00aaff" fill="url(#agSUB)" strokeWidth={2.5} dot={false} />
            <Legend wrapperStyle={{ fontFamily:'Space Mono', fontSize:11, paddingTop:12, color:'#5b6f8a' }} />
          </AreaChart>
        </ResponsiveContainer>
      </Card>

      {/* ── Financial Impact ── */}
      <Card style={{ background:'rgba(0,229,160,0.03)', borderColor:'rgba(0,229,160,0.15)' }}>
        <SectionLabel>Estimated Financial Impact Prevented</SectionLabel>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:20, marginTop:8 }}>
          {[
            { type:'Wangiri',      saved:'$84,200',  color:'#ff4466' },
            { type:'Smishing',     saved:'$61,500',  color:'#a78bfa' },
            { type:'SIM Box',      saved:'$112,800', color:'#f59e0b' },
            { type:'Subscription', saved:'$38,900',  color:'#00aaff' },
          ].map(item => (
            <div key={item.type} style={{ textAlign:'center', padding:'14px 10px', background:'var(--bg-card)', borderRadius:10 }}>
              <div style={{ fontSize:22, fontWeight:800, color:item.color, fontFamily:'var(--mono)' }}>{item.saved}</div>
              <div style={{ fontSize:12, color:'var(--muted)', marginTop:5 }}>{item.type}</div>
            </div>
          ))}
        </div>
        <div style={{ textAlign:'center', marginTop:16, fontSize:14, color:'var(--muted)' }}>
          Total estimated savings this month: <span style={{ color:'var(--accent)', fontWeight:800, fontSize:18 }}>$297,400</span>
        </div>
      </Card>
    </div>
  );
}
