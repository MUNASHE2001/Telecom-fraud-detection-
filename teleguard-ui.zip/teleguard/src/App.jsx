// ============================================================
//  TeleGuard — App.jsx (Router / Shell)
// ============================================================
import React, { useState } from 'react';
import './styles/globals.css';

import { Sidebar }      from './components/Sidebar';
import LoginPage        from './pages/LoginPage';
import DashboardPage    from './pages/DashboardPage';
import AlertsPage       from './pages/AlertsPage';
import CasePage         from './pages/CasePage';
import AnalyticsPage    from './pages/AnalyticsPage';
import { SubscriberPage, AuditPage, SettingsPage } from './pages/OtherPages';

export default function App() {
  const [authed,   setAuthed]   = useState(false);
  const [page,     setPage]     = useState('dashboard');

  // ── Not logged in ──────────────────────────────────────────
  if (!authed) {
    return <LoginPage onLogin={() => setAuthed(true)} />;
  }

  // ── Page renderer ──────────────────────────────────────────
  const renderPage = () => {
    switch (page) {
      case 'dashboard':  return <DashboardPage  onNavigate={setPage} />;
      case 'alerts':     return <AlertsPage     onNavigate={setPage} />;
      case 'case':       return <CasePage       onNavigate={setPage} />;
      case 'analytics':  return <AnalyticsPage  onNavigate={setPage} />;
      case 'subscriber': return <SubscriberPage onNavigate={setPage} />;
      case 'audit':      return <AuditPage      onNavigate={setPage} />;
      case 'settings':   return <SettingsPage   onNavigate={setPage} />;
      default:           return <DashboardPage  onNavigate={setPage} />;
    }
  };

  // ── Authenticated shell ────────────────────────────────────
  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'var(--bg-base)' }}>
      <Sidebar active={page} onNavigate={setPage} />

      {/* Main content area */}
      <main style={{ flex:1, overflowY:'auto', minWidth:0 }}>

        {/* Top bar */}
        <div style={{
          position:'sticky', top:0, zIndex:10,
          background:'rgba(7,9,15,0.85)',
          backdropFilter:'blur(14px)',
          borderBottom:'1px solid var(--border-dim)',
          padding:'12px 36px',
          display:'flex', justifyContent:'space-between', alignItems:'center',
        }}>
          <div style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'2px' }}>
            {page.toUpperCase().replace('CASE','CASE INVESTIGATION')}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:20 }}>
            {/* Simulated live alert */}
            <div style={{
              display:'flex', alignItems:'center', gap:8, padding:'6px 14px',
              background:'rgba(255,68,102,0.1)', border:'1px solid rgba(255,68,102,0.25)',
              borderRadius:8, cursor:'pointer',
            }}
            onClick={()=>setPage('alerts')}
            >
              <span style={{ width:7, height:7, borderRadius:'50%', background:'#ff4466', display:'inline-block', animation:'livePulse 1.5s infinite' }} />
              <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'#ff8888', fontWeight:700 }}>47 Active Threats</span>
            </div>
            <style>{`@keyframes livePulse{0%{box-shadow:0 0 0 0 rgba(255,68,102,0.5)}70%{box-shadow:0 0 0 8px transparent}100%{box-shadow:0 0 0 0 transparent}}`}</style>

            {/* Logout */}
            <button
              onClick={()=>setAuthed(false)}
              style={{ background:'transparent', border:'1px solid var(--border-dim)', borderRadius:7, padding:'6px 14px', color:'var(--muted)', fontFamily:'var(--font)', fontSize:13, cursor:'pointer', transition:'all 0.15s' }}
              onMouseEnter={e=>{e.currentTarget.style.color='var(--text)';e.currentTarget.style.borderColor='var(--border)';}}
              onMouseLeave={e=>{e.currentTarget.style.color='var(--muted)';e.currentTarget.style.borderColor='var(--border-dim)';}}
            >
              Sign Out
            </button>
          </div>
        </div>

        {/* Page content */}
        {renderPage()}
      </main>
    </div>
  );
}
