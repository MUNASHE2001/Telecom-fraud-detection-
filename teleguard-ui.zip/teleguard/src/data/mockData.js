// ============================================================
//  TeleGuard — Mock Data (replaces all backend API calls)
// ============================================================

export const FRAUD_TYPES = {
  SIM:  { label: 'SIM Box',     color: '#f59e0b', bg: 'rgba(245,158,11,0.1)',   icon: '⚡' },
  SMS:  { label: 'Smishing',    color: '#a78bfa', bg: 'rgba(167,139,250,0.1)',  icon: '✉️' },
  SUB:  { label: 'Subscription',color: '#00aaff', bg: 'rgba(0,170,255,0.1)',    icon: '🔑' },
  WAN:  { label: 'Wangiri',     color: '#ff4466', bg: 'rgba(255,68,102,0.1)',   icon: '📞' },
};

export const SEVERITY = {
  CRITICAL: { label: 'Critical', color: '#ff4466' },
  HIGH:     { label: 'High',     color: '#ff8c42' },
  MEDIUM:   { label: 'Medium',   color: '#f59e0b' },
  LOW:      { label: 'Low',      color: '#00e5a0' },
};

// Dashboard KPIs
export const kpiData = {
  totalAlerts:     { value: 1_284, delta: '+14%', up: true  },
  activeThreats:   { value: 47,    delta: '+3',   up: true  },
  resolvedToday:   { value: 189,   delta: '+22%', up: true  },
  falsePositives:  { value: 2.4,   delta: '-0.8%',up: false },
};

// Live alert feed (dashboard)
export const liveAlerts = [
  { id: 'A1001', type: 'WAN',  number: '+2637712345678', confidence: 97, severity: 'CRITICAL', time: '2 min ago',  status: 'OPEN'       },
  { id: 'A1002', type: 'SMS',  number: '+2637698765432', confidence: 91, severity: 'HIGH',     time: '5 min ago',  status: 'OPEN'       },
  { id: 'A1003', type: 'SIM',  number: '+2637634567890', confidence: 88, severity: 'HIGH',     time: '11 min ago', status: 'OPEN'       },
  { id: 'A1004', type: 'SUB',  number: '+2637756789012', confidence: 79, severity: 'MEDIUM',   time: '18 min ago', status: 'OPEN'       },
  { id: 'A1005', type: 'WAN',  number: '+2637823456789', confidence: 95, severity: 'CRITICAL', time: '26 min ago', status: 'INVESTIGATING'},
  { id: 'A1006', type: 'SMS',  number: '+2637787654321', confidence: 83, severity: 'HIGH',     time: '34 min ago', status: 'OPEN'       },
  { id: 'A1007', type: 'SIM',  number: '+2637645678901', confidence: 76, severity: 'MEDIUM',   time: '41 min ago', status: 'RESOLVED'   },
  { id: 'A1008', type: 'SUB',  number: '+2637712398765', confidence: 68, severity: 'LOW',      time: '55 min ago', status: 'RESOLVED'   },
];

// Full alerts list (Alerts Center page)
export const allAlerts = [
  ...liveAlerts,
  { id: 'A0999', type: 'WAN',  number: '+2637799887766', confidence: 92, severity: 'CRITICAL', time: '1 hr ago',   status: 'RESOLVED'   },
  { id: 'A0998', type: 'SIM',  number: '+2637611223344', confidence: 84, severity: 'HIGH',     time: '1 hr ago',   status: 'RESOLVED'   },
  { id: 'A0997', type: 'SMS',  number: '+2637788990011', confidence: 71, severity: 'MEDIUM',   time: '2 hrs ago',  status: 'DISMISSED'  },
  { id: 'A0996', type: 'SUB',  number: '+2637722334455', confidence: 65, severity: 'LOW',      time: '2 hrs ago',  status: 'RESOLVED'   },
  { id: 'A0995', type: 'WAN',  number: '+2637733445566', confidence: 89, severity: 'HIGH',     time: '3 hrs ago',  status: 'RESOLVED'   },
  { id: 'A0994', type: 'SMS',  number: '+2637744556677', confidence: 94, severity: 'CRITICAL', time: '3 hrs ago',  status: 'RESOLVED'   },
];

// Fraud trend chart (7 days)
export const fraudTrend = [
  { day: 'Mon', SIM: 14, SMS: 22, SUB: 8,  WAN: 31 },
  { day: 'Tue', SIM: 18, SMS: 19, SUB: 11, WAN: 27 },
  { day: 'Wed', SIM: 22, SMS: 31, SUB: 9,  WAN: 35 },
  { day: 'Thu', SIM: 17, SMS: 25, SUB: 14, WAN: 29 },
  { day: 'Fri', SIM: 29, SMS: 38, SUB: 18, WAN: 42 },
  { day: 'Sat', SIM: 11, SMS: 14, SUB: 6,  WAN: 19 },
  { day: 'Sun', SIM: 9,  SMS: 11, SUB: 5,  WAN: 16 },
];

// Single case investigation
export const caseDetail = {
  id: 'A1001',
  type: 'WAN',
  severity: 'CRITICAL',
  status: 'OPEN',
  confidence: 97,
  detectedAt: '2025-04-29 · 09:14:22',
  subscriber: {
    number: '+263 77 123 4567',
    account: 'ACC-887234',
    name: 'Unknown / Unverified',
    network: 'NetOne ZW',
    registeredAt: '2025-04-01',
    idVerified: false,
  },
  evidence: [
    { feature: 'Short outbound calls (< 3s)',   value: '412 calls',   weight: 31, impact: 'high' },
    { feature: 'Distinct destinations',          value: '389 numbers', weight: 28, impact: 'high' },
    { feature: 'Premium-rate prefixes targeted', value: '94%',         weight: 22, impact: 'high' },
    { feature: 'Callback ratio observed',        value: '61%',         weight: 12, impact: 'medium' },
    { feature: 'Active hours anomaly',           value: '02:00–04:30', weight: 7,  impact: 'low' },
  ],
  timeline: [
    { time: '09:14:22', event: 'Anomaly flagged by Isolation Forest' },
    { time: '09:14:23', event: 'Random Forest classified: Wangiri (97%)' },
    { time: '09:14:23', event: 'SHAP explanation computed' },
    { time: '09:14:24', event: 'Critical alert generated → Dashboard' },
    { time: '09:15:01', event: 'Notification sent to Admin #1' },
  ],
  recommended: 'Immediately block outbound calling from this number. Escalate to network operations for SIM deactivation review.',
};

// Subscriber lookup results
export const subscriberProfiles = [
  {
    id: 'ACC-887234', number: '+263 77 123 4567', name: 'Unverified', network: 'NetOne ZW',
    riskScore: 97, fraudFlags: ['WAN'], status: 'FLAGGED',
    activity: { calls: 412, sms: 3, activations: 1 },
  },
  {
    id: 'ACC-334521', number: '+263 78 456 7890', name: 'Rumbidzai M.', network: 'Econet ZW',
    riskScore: 12, fraudFlags: [], status: 'CLEAN',
    activity: { calls: 18, sms: 44, activations: 0 },
  },
  {
    id: 'ACC-776654', number: '+263 71 234 5678', name: 'Unknown', network: 'Telecel ZW',
    riskScore: 81, fraudFlags: ['SMS', 'SUB'], status: 'FLAGGED',
    activity: { calls: 7, sms: 2340, activations: 4 },
  },
];

// Audit log
export const auditLog = [
  { id: 'L001', admin: 'admin@teleguard.net', action: 'RESOLVED alert A0998',         time: '09:44:11', ip: '10.0.0.12' },
  { id: 'L002', admin: 'analyst@teleguard.net',action:'OPENED case A1001',            time: '09:40:32', ip: '10.0.0.15' },
  { id: 'L003', admin: 'admin@teleguard.net', action: 'Updated alert threshold → 85%',time: '09:32:09', ip: '10.0.0.12' },
  { id: 'L004', admin: 'analyst@teleguard.net',action:'DISMISSED alert A0997',        time: '09:21:44', ip: '10.0.0.15' },
  { id: 'L005', admin: 'admin@teleguard.net', action: 'Exported fraud report (daily)',time: '08:55:00', ip: '10.0.0.12' },
  { id: 'L006', admin: 'admin@teleguard.net', action: 'LOGIN success',                time: '08:50:11', ip: '10.0.0.12' },
  { id: 'L007', admin: 'analyst@teleguard.net',action:'LOGIN success',                time: '08:48:33', ip: '10.0.0.15' },
  { id: 'L008', admin: 'admin@teleguard.net', action: 'RESOLVED alert A0994',         time: 'Yesterday', ip: '10.0.0.12' },
];

// Analytics monthly data
export const monthlyStats = [
  { month: 'Nov', total: 312 }, { month: 'Dec', total: 289 },
  { month: 'Jan', total: 401 }, { month: 'Feb', total: 377 },
  { month: 'Mar', total: 445 }, { month: 'Apr', total: 521 },
];

export const fraudDistribution = [
  { name: 'Wangiri',      value: 38 },
  { name: 'Smishing',     value: 27 },
  { name: 'SIM Box',      value: 22 },
  { name: 'Subscription', value: 13 },
];
